$ErrorActionPreference = "Stop"

$repo = "https://github.com/j3p3rg/GIFTBYT/releases/latest/download/tytspot-windows-x64.zip"
$installRoot = Join-Path $env:USERPROFILE ".tytspot"
$binDir = Join-Path $installRoot "bin"
$tempZip = Join-Path $env:TEMP "tytspot-windows-x64.zip"
$tempExtract = Join-Path $env:TEMP "tytspot-cli"

New-Item -ItemType Directory -Force -Path $binDir | Out-Null
if (Test-Path $tempExtract) {
  Remove-Item -Recurse -Force $tempExtract
}

Invoke-WebRequest -UseBasicParsing $repo -OutFile $tempZip
Expand-Archive -Path $tempZip -DestinationPath $tempExtract -Force
Copy-Item (Join-Path $tempExtract "tytspot-win-x64.exe") (Join-Path $binDir "tytspot.exe") -Force

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
$pathItems = @()
if ($userPath) {
  $pathItems = $userPath.Split(';') | Where-Object { $_ }
}
if ($pathItems -notcontains $binDir) {
  $newPath = if ($userPath) { "$userPath;$binDir" } else { $binDir }
  [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
}

Write-Host "TYTSPOT CLI installed to $binDir"
Write-Host "Open a new terminal, then run: tytspot help"
