#!/usr/bin/env bash
set -euo pipefail

RELEASE_URL="https://github.com/j3p3rg/GIFTBYT/releases/latest/download/tytspot-linux-x64.tar.gz"
INSTALL_ROOT="${HOME}/.tytspot"
BIN_DIR="${INSTALL_ROOT}/bin"
TMP_DIR="$(mktemp -d)"

mkdir -p "${BIN_DIR}"
curl -fsSL "${RELEASE_URL}" -o "${TMP_DIR}/tytspot-linux-x64.tar.gz"
tar -xzf "${TMP_DIR}/tytspot-linux-x64.tar.gz" -C "${TMP_DIR}"
cp "${TMP_DIR}/tytspot-linux-x64" "${BIN_DIR}/tytspot"
chmod +x "${BIN_DIR}/tytspot"

PROFILE_FILE="${HOME}/.bashrc"
if [ -n "${ZSH_VERSION:-}" ]; then
  PROFILE_FILE="${HOME}/.zshrc"
fi

if ! grep -Fq "${BIN_DIR}" "${PROFILE_FILE}" 2>/dev/null; then
  printf '\nexport PATH="%s:$PATH"\n' "${BIN_DIR}" >> "${PROFILE_FILE}"
fi

echo "TYTSPOT CLI installed to ${BIN_DIR}"
echo "Open a new terminal, then run: tytspot help"
