#!/usr/bin/env bash
set -euo pipefail

ARCH="$(uname -m)"
if [ "${ARCH}" = "arm64" ]; then
  RELEASE_URL="https://github.com/j3p3rg/GIFTBYT/releases/latest/download/tytspot-macos-arm64.tar.gz"
  BINARY_NAME="tytspot-macos-arm64"
else
  RELEASE_URL="https://github.com/j3p3rg/GIFTBYT/releases/latest/download/tytspot-macos-x64.tar.gz"
  BINARY_NAME="tytspot-macos-x64"
fi

INSTALL_ROOT="${HOME}/.tytspot"
BIN_DIR="${INSTALL_ROOT}/bin"
TMP_DIR="$(mktemp -d)"

mkdir -p "${BIN_DIR}"
curl -fsSL "${RELEASE_URL}" -o "${TMP_DIR}/tytspot-macos.tar.gz"
tar -xzf "${TMP_DIR}/tytspot-macos.tar.gz" -C "${TMP_DIR}"
cp "${TMP_DIR}/${BINARY_NAME}" "${BIN_DIR}/tytspot"
chmod +x "${BIN_DIR}/tytspot"

PROFILE_FILE="${HOME}/.zshrc"
if [ -n "${BASH_VERSION:-}" ]; then
  PROFILE_FILE="${HOME}/.bash_profile"
fi

if ! grep -Fq "${BIN_DIR}" "${PROFILE_FILE}" 2>/dev/null; then
  printf '\nexport PATH="%s:$PATH"\n' "${BIN_DIR}" >> "${PROFILE_FILE}"
fi

echo "TYTSPOT CLI installed to ${BIN_DIR}"
echo "Open a new terminal, then run: tytspot help"
